package com.junqin.service;

import java.util.List;

import com.junqin.domain.Article;
import com.junqin.domain.PageContent;

public interface ArticleService {

	void addArticle(Article article);

	List<Article> getArticle(String part);
  
	Article getArtcleById(String id);

	List<Article> getArtcleList();

	PageContent getPage();

	List<Article> getArtcleList(int page);

	void deleteArticle(String id);

}
