package com.junqin.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.junqin.domain.Article;
import com.junqin.domain.Lmessage;
import com.junqin.service.LeaveMessageService;
import com.junqin.tools.HttpReturn;

@Controller()
@RequestMapping("/leaveMessage")
public class LeaveMessageController {

	@Resource
	private LeaveMessageService leaveMessageService;
	
	

	@RequestMapping(value = "/addMessage", method = RequestMethod.POST)
	@ResponseBody
	public void addMessage(HttpServletRequest request, @RequestBody String json, HttpServletResponse response) {
		Lmessage lmessage=JSON.parseObject(json,Lmessage.class);
	    leaveMessageService.addMessage(lmessage);
		HttpReturn.reponseBody(response, "true");
        
	}
	
	@RequestMapping(value = "/feedBack", method = RequestMethod.POST)
	@ResponseBody
	public void feedBack(HttpServletRequest request, @RequestBody String json, HttpServletResponse response) {
		Lmessage lmessage=JSON.parseObject(json,Lmessage.class);
	    leaveMessageService.updateMessage(lmessage);
		HttpReturn.reponseBody(response, "true");
        
	}
	
	@RequestMapping(value = "/deleteMessage", method = RequestMethod.POST)
	@ResponseBody
	public void deleteMessage(HttpServletRequest request, @RequestBody String json, HttpServletResponse response) {
		Lmessage lmessage=JSON.parseObject(json,Lmessage.class);
	    leaveMessageService.updateMessage(lmessage);
		HttpReturn.reponseBody(response, "true");
        
	}
	
	
}
