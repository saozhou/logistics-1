package com.junqin.dao;

import com.junqin.domain.BBSArticle;
import com.junqin.domain.BBSUser;

public interface BBSUserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(BBSUser record);

    int insertSelective(BBSUser record);

    BBSUser selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(BBSUser record);

    int updateByPrimaryKey(BBSUser record);

	BBSUser selectByName(String name);

	BBSArticle selectByPrimaryKey(String id);

	BBSArticle selectById(String id);
}