package com.junqin.domain;

public class BBSUser {
    private Integer id;

    private String username;

    private String password;

    private String createtime;

    private String lastlogintime;

    private Integer loginnumbers;

    private Integer outnumbers;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime == null ? null : createtime.trim();
    }

    public String getLastlogintime() {
        return lastlogintime;
    }

    public void setLastlogintime(String lastlogintime) {
        this.lastlogintime = lastlogintime == null ? null : lastlogintime.trim();
    }

    public Integer getLoginnumbers() {
        return loginnumbers;
    }

    public void setLoginnumbers(Integer loginnumbers) {
        this.loginnumbers = loginnumbers;
    }

    public Integer getOutnumbers() {
        return outnumbers;
    }

    public void setOutnumbers(Integer outnumbers) {
        this.outnumbers = outnumbers;
    }
}