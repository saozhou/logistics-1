package com.junqin.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.junqin.dao.LmessageMapper;
import com.junqin.domain.Lmessage;
import com.junqin.service.LeaveMessageService;

@Service("leaveMessageService")
public class LeaveMessageServiceImpl implements LeaveMessageService{

	@Resource
	private LmessageMapper lmessageDao;

	@Override
	public void addMessage(Lmessage lmessage) {
		// TODO Auto-generated method stub
	    lmessageDao.insert(lmessage);	
	}

	@Override
	public void updateMessage(Lmessage lmessage) {
		// TODO Auto-generated method stub
		lmessageDao.updateByPrimaryKey(lmessage);
	}

	@Override
	public List<Lmessage> getUnreadEmail() {
		// TODO Auto-generated method stub
		List<Lmessage>list = lmessageDao.selectUnread();
		 
		return list;
	}

	@Override
	public List<Lmessage> getSlovedMail() {
		// TODO Auto-generated method stub
		List<Lmessage>list = lmessageDao.selectSloved();
		return list;
	}
	
	
	
}
