package com.junqin.controller;

import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.junqin.dao.ReturnStatude;
import com.junqin.domain.User;
import com.junqin.service.UserService;
import com.junqin.tools.HttpReturn;
import com.junqin.tools.Json2Map;

/**
 * 
 * @author Zhou 用户控制类
 */
@Controller
@RequestMapping("/user")
public class UserController {
	@Resource
	private UserService userService;

	/**
	 * 
	 * @param request
	 * @param model
	 * @return 用户登陆
	 */
	@RequestMapping(value = "/userindex", method = RequestMethod.GET)
	@ResponseBody
	public void index(HttpServletRequest request,   HttpServletResponse response) {

		 
		response.setContentType("text/html;charset=utf-8");
		int i = 0;
	
		String username = request.getParameter("username");
		String password =request.getParameter("password");
		System.out.println(username);
		User users = new User();
		users.setUsername(username);
		users.setPassword(password);
		User user = this.userService.checkUser(users);
		if (user == null) {
			i = 1;
			HttpReturn.reponseBody(response, "fail");

		}else if (i == 0) {
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			ReturnStatude sa = new ReturnStatude();
			sa.setState("success");
			String json = JSON.toJSONString(sa);
			HttpReturn.reponseBody(response, json);
			 
		}

	}

	/**
	 * 
	 * @param request
	 * @param model
	 * @return 用户名查重
	 */
	@RequestMapping(value = "/checkUsername", method = RequestMethod.POST)
	@ResponseBody
	public void checkUsername(HttpServletRequest request, @RequestBody String json, HttpServletResponse response) {
		Map<String, String> map = Json2Map.JSON2Map(json);
		String username = map.get("username");
		boolean usernameexit = userService.getSameName(username);
		
		if (usernameexit) {
			HttpReturn.reponseBody(response, "false");
		
		}else if (!usernameexit) {
			HttpReturn.reponseBody(response, "ture");
		}
	}

	/**
	 * 
	 * @param request
	 * @param model
	 * @return 用户注册
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	@ResponseBody
	public void register(HttpServletRequest request, @RequestBody String json, HttpServletResponse response) {
	 
		User user=JSON.parseObject(json,User.class);
	    userService.addUser(user);
		HttpReturn.reponseBody(response, "true");
		 
	}
	 
	/**
	 * 
	 * @param request
	 * @param response
	 * @param json
	 *            用户信息修改
	 */
	@RequestMapping(value = "/userupdate", method = RequestMethod.POST)
	@ResponseBody
	public void userUpdate(HttpServletRequest request, HttpServletResponse response, @RequestBody String json) {
		Map<String, String> map = Json2Map.JSON2Map(json);
		String username = map.get("username");
		String password = map.get("password");
		String address = map.get("address");
		//userService.userUpdate(username, password, address);
		HttpReturn.reponseBody(response, "保存成功");
	}

    
 

	/**
	 * 
	 * @param request
	 * @param response
	 * @param json
	 *            Session更改
	 */
	@RequestMapping(value = "/sessionchange", method = RequestMethod.POST)
	@ResponseBody
	public String SessionChange(HttpServletRequest request, HttpServletResponse response, @RequestBody String json) {
		Map<String, String> map = Json2Map.JSON2Map(json);
		Set<String> key = map.keySet();
		HttpSession session = request.getSession();
		String value = null;
		for (String temp : key) {
			value = map.get(temp);
			session.setAttribute(temp, value);
		}
		return json;
	}
}
