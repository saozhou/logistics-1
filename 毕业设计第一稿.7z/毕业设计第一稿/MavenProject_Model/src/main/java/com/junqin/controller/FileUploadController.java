package com.junqin.controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.junqin.tools.HttpReturn;

 
@Controller
@RequestMapping("videoUpload")
public class FileUploadController {
	public void GFReferenceUpload(MultipartFile file, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		response.setContentType("text/html;charset=utf-8");
		String fileLevel = file.getOriginalFilename();
		String fileName = fileLevel.substring(fileLevel.indexOf(".") + 1, fileLevel.length());
		String path = "D:\\Users";
		fileLevel = fileLevel.substring(fileLevel.indexOf(".") + 1, fileLevel.length());
		String allPath = path + "\\" + fileName;
		File dir = new File(allPath, fileName);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		// MultipartFile自带的解析方法
		file.transferTo(dir);
		response.setContentType("text/html;charset=utf-8");
		HttpReturn.reponseBody(response, "上传成功");
	}

	 
		   

 
	}

