package com.junqin.serviceimpl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.junqin.dao.UserMapper;
import com.junqin.domain.User;
import com.junqin.service.UserService;
@Service("userService")
public class UserviceImpl implements UserService{

	@Resource
	private UserMapper userDao;
	
	@Override
	public User checkUser(User users) {
		// TODO Auto-generated method stub
		User user = userDao.getUser(users);
		return user;
	}

	@Override
	public boolean getSameName(String username) {
		// TODO Auto-generated method stub
		String eusername = userDao.checkUsername(username);
		if(eusername==null){
			return false;
		}else{
			return true;
		}
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		userDao.insert(user);
	}

}
