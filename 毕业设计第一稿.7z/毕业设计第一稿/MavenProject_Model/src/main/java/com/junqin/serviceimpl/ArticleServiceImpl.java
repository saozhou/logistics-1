package com.junqin.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.junqin.dao.ArticleMapper;
import com.junqin.domain.Article;
import com.junqin.domain.PageContent;
import com.junqin.service.ArticleService;
@Service("articleService")
public class ArticleServiceImpl implements ArticleService{

	@Resource
	private ArticleMapper articleDao;
	@Override
	public void addArticle(Article article) {
		// TODO Auto-generated method stub
		articleDao.insert(article);
	}
	@Override
	public List<Article> getArticle(String part) {
		// TODO Auto-generated method stub
		List<Article>list = articleDao.selectByPart(part);
		return list;
	}
	@Override
	public Article getArtcleById(String id) {
		// TODO Auto-generated method stub
		Article article = articleDao.selectByPrimaryKey(id);
		return article;
	}
	@Override
	public List<Article> getArtcleList() {
		// TODO Auto-generated method stub
		List<Article>list = articleDao.selectArticleList();
		return list;
	}
	@Override
	public PageContent getPage() {
		// TODO Auto-generated method stub
		PageContent content = new PageContent();
		double total = articleDao.selectTotalCount();
		int flag = (int) Math.ceil(total / 25);		//向上取整计算
		content.setTotalPage(flag);
		content.setCurrentPage(1);
		content.setNextPage(2); 
		return content;
	}
	@Override
	public List<Article> getArtcleList(int page) {
		// TODO Auto-generated method stub
		List<Article>list = articleDao.selectPageNext(page);
		return list;
	}
	@Override
	public void deleteArticle(String id) {
		// TODO Auto-generated method stub
		articleDao.deleteByPrimaryKey(id);
	}

}
