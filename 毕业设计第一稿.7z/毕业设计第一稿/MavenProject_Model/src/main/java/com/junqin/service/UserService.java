package com.junqin.service;

import com.junqin.domain.User;

public interface UserService {

	User checkUser(User users);

	boolean getSameName(String username);

	void addUser(User user);

}
