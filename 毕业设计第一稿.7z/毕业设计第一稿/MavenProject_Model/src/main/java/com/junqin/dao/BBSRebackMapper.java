package com.junqin.dao;

import com.junqin.domain.BBSReback;

public interface BBSRebackMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(BBSReback record);

    int insertSelective(BBSReback record);

    BBSReback selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(BBSReback record);

    int updateByPrimaryKey(BBSReback record);
}