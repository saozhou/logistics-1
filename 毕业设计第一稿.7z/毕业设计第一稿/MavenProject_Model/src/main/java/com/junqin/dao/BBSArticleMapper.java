package com.junqin.dao;

import java.util.List;

import com.junqin.domain.BBSArticle;

public interface BBSArticleMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(BBSArticle record);

    int insertSelective(BBSArticle record);

    BBSArticle selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(BBSArticle record);

    int updateByPrimaryKeyWithBLOBs(BBSArticle record);

    int updateByPrimaryKey(BBSArticle record);

	List<BBSArticle> selectByPrimaryKey(String id);

	BBSArticle selectById(String id);

	List<BBSArticle> selectList();

	void deleteByPrimaryKey(String id);
}