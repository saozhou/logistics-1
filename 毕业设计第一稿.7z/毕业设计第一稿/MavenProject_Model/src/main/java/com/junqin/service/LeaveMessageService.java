package com.junqin.service;

import java.util.List;

import com.junqin.domain.Lmessage;

public interface LeaveMessageService {

	void addMessage(Lmessage lmessage);

	void updateMessage(Lmessage lmessage);

	List<Lmessage> getUnreadEmail();

	List<Lmessage> getSlovedMail();

}
