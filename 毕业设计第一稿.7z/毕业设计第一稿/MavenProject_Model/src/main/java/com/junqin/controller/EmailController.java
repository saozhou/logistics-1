package com.junqin.controller;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.junqin.domain.Lmessage;
import com.junqin.service.LeaveMessageService;
import com.junqin.tools.HttpReturn;

@Controller
@RequestMapping("/email")
public class EmailController {
    @Resource
	private LeaveMessageService leaveMessage;
    
    
   /**
	 * 
	 * @param request
	 * @param json
	 * @param response
	 * 
	 * 添加文章
	 */
	@RequestMapping(value = "/addemail", method = RequestMethod.POST)
	
	public String addMessage(HttpServletRequest request,  HttpServletResponse response) {
          String name = request.getParameter("name");
          String email = request.getParameter("email");
          String mycall = request.getParameter("mycall");
          String lytext = request.getParameter("lytext");
          Lmessage lmessage = new Lmessage();
          lmessage.setQname(name);
          lmessage.setEmail(email);
          lmessage.setMycall(mycall);
          lmessage.setQcontent(lytext);
          lmessage.setStatus(0);
          Date day=new Date();    
  		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
  		String date=df.format(day);   
  		 lmessage.setQtime(date);
          leaveMessage.addMessage(lmessage);
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		 
	  return "email";
	}
	
@RequestMapping(value = "/getUnreadEmail", method = RequestMethod.GET)
	@ResponseBody
	public void getUnreadEmail(HttpServletRequest request,  HttpServletResponse response) {
        
	     List<Lmessage>list = leaveMessage.getUnreadEmail();
	      

			try {
				request.setCharacterEncoding("utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 这里不设置编码会有乱码
			response.setContentType("text/html;charset=utf-8");
			if (list != null) {
				String json = JSON.toJSONString(list);
				HttpReturn.reponseBody(response, json);
			}
			 
	 
	}


@RequestMapping(value = "/getSlovedEmail", method = RequestMethod.GET)
@ResponseBody
public void getSlovedEmail(HttpServletRequest request,  HttpServletResponse response) {
    
     List<Lmessage>list = leaveMessage.getSlovedMail();
             
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		response.setContentType("text/html;charset=utf-8");
		if (list != null) {
			String json = JSON.toJSONString(list);
			HttpReturn.reponseBody(response, json);
		}
		 
 
}


@RequestMapping(value = "/getAllemail", method = RequestMethod.GET)
@ResponseBody
public void getAllemail(HttpServletRequest request,  HttpServletResponse response) {
    
     List<Lmessage>list = leaveMessage.getUnreadEmail();

		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		response.setContentType("text/html;charset=utf-8");
		if (list != null) {
			String json = JSON.toJSONString(list);
			HttpReturn.reponseBody(response, json);
		}
		 
 
}


}
