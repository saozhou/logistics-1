package com.junqin.domain;

public class BBSArticle {
    private Integer id;

    private String creater;

    private String model;

    private String title;

    private String createtime;

    private String content;
    
    private int readtime;
    
    private int rebacknumber;

    public int getReadtime() {
		return readtime;
	}

	public void setReadtime(int readtime) {
		this.readtime = readtime;
	}

	public int getRebacknumber() {
		return rebacknumber;
	}

	public void setRebacknumber(int rebacknumber) {
		this.rebacknumber = rebacknumber;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater == null ? null : creater.trim();
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model == null ? null : model.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime == null ? null : createtime.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
}