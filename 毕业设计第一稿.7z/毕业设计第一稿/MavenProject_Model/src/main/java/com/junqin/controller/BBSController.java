package com.junqin.controller;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.junqin.dao.ReturnStatude;
import com.junqin.domain.Article;
import com.junqin.domain.BBSArticle;
import com.junqin.domain.BBSUser;
import com.junqin.domain.Model;
import com.junqin.service.BBSService;
import com.junqin.tools.HttpReturn;

@Controller
@RequestMapping("/BBS")
public class BBSController {
	@Resource
	private BBSService bbsService;
	
	
	/**
	 * 
	 * @param request
	 * @param json
	 * @param response
	 * 
	 * 添加文章
	 */
	@RequestMapping(value = "/addArticle", method = RequestMethod.GET)
	@ResponseBody
	public void addArticle(HttpServletRequest request,  HttpServletResponse response) {

		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		response.setContentType("text/html;charset=utf-8");
		Date day=new Date();    
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		String date=df.format(day);   
		String username = (String) request.getSession().getAttribute("username");
	    String title = request.getParameter("title");
	    String content = request.getParameter("content");
	    String model = request.getParameter("model");
	    BBSArticle article = new BBSArticle();
	    article.setContent(content);
	    article.setCreater(username);
	    article.setModel(model);
	    article.setCreatetime(date);
	    article.setTitle(title);
	    bbsService.addArticle(article);
	    ReturnStatude st = new ReturnStatude();
	    st.setState("success");
	    String json = JSON.toJSONString(st);
		HttpReturn.reponseBody(response, json);
	
	}
	
	
	@RequestMapping(value = "/getBBSmodelContent", method = RequestMethod.GET)
	@ResponseBody
	public void getBBSmodelContent(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		 String id = request.getParameter("id");
		 Model model = bbsService.getModelById(id); 
		 
			response.setContentType("text/html;charset=utf-8");
			if (model != null) {
				String json = JSON.toJSONString(model);
				HttpReturn.reponseBody(response, json);
			}
	 
		
	}
	
	 
	
	@RequestMapping(value = "/getBBSContent", method = RequestMethod.GET)
	@ResponseBody
	public void getBBSContent(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		
		 String id = request.getParameter("id");
		 BBSArticle article = bbsService.getArticleById(id); 
		 
			response.setContentType("text/html;charset=utf-8");
			if (article != null) {
				String json = JSON.toJSONString(article);
				System.out.println(json);
				HttpReturn.reponseBody(response, json);
			}
	  
		
	}
	
	@RequestMapping(value = "/getBBSmodelContentList", method = RequestMethod.GET)
	@ResponseBody
	public void getBBSmodelContentList(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		 
		 List<BBSArticle>list = bbsService.getBBsArticleList();
		 
			response.setContentType("text/html;charset=utf-8");
			if (list != null) {
				String json = JSON.toJSONString(list);
				System.out.println(json);
				HttpReturn.reponseBody(response, json);
			}
	  
		
	}
	
	@RequestMapping(value = "/getBBSList", method = RequestMethod.GET)
	@ResponseBody
	public void getBBSList(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		
		 String id = request.getParameter("id");
		 Model model = bbsService.getModelById(id); 
		 List<BBSArticle>list = bbsService.getArticleList(model.getName());
		 
			response.setContentType("text/html;charset=utf-8");
			if (list != null) {
				String json = JSON.toJSONString(list);
				System.out.println(json);
				HttpReturn.reponseBody(response, json);
			}
	 
	     
		
	}
	
	@RequestMapping(value = "/deleteArticle", method = RequestMethod.GET)
	@ResponseBody
	public void deleteArticle(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		response.setContentType("text/html;charset=utf-8"); 
		String id = request.getParameter("id");
		System.out.println(id);
	 
		bbsService.deleteArticle(id);
	    ReturnStatude st = new ReturnStatude();
	    st.setState("success");
	    String json = JSON.toJSONString(st);
		HttpReturn.reponseBody(response, json);
	     
		
	}
	

	@RequestMapping(value = "/getBBSUser", method = RequestMethod.GET)
	@ResponseBody
	public void getBBSUser(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 这里不设置编码会有乱码
		
		 String name = request.getParameter("name");
		 BBSUser model = bbsService.getBBSUser(name); 
		 
			response.setContentType("text/html;charset=utf-8");
			if (model != null) {
				String json = JSON.toJSONString(model);
				System.out.println(json);
				HttpReturn.reponseBody(response, json);
			}
	 
	     
		
	}
}
