package com.junqin.service;

import java.util.List;

import com.junqin.domain.BBSArticle;
import com.junqin.domain.BBSUser;
import com.junqin.domain.Model;

public interface BBSService {

	Model getModelById(String id);

	List<BBSArticle> getArticleList(String id);

	BBSUser getBBSUser(String name);

	BBSArticle getArticleById(String id);

	List<BBSArticle> getBBsArticleList();

	void deleteArticle(String id);

	void addArticle(BBSArticle article);

}
