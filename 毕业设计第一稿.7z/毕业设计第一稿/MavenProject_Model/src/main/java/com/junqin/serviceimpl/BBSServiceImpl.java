package com.junqin.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.junqin.dao.BBSArticleMapper;
import com.junqin.dao.BBSUserMapper;
import com.junqin.dao.ModelMapper;
import com.junqin.domain.BBSArticle;
import com.junqin.domain.BBSUser;
import com.junqin.domain.Model;
import com.junqin.service.BBSService;

@Service("bbsService")
public class BBSServiceImpl implements BBSService{

	@Resource
	private ModelMapper modelDao;
	@Resource
	private BBSArticleMapper articleDao;
	@Resource
	private BBSUserMapper userDao;
	@Override
	public Model getModelById(String id) {
		// TODO Auto-generated method stub
		return modelDao.selectByPrimaryKey(id);
	}
	@Override
	public List<BBSArticle> getArticleList(String id) {
		// TODO Auto-generated method stub
		return articleDao.selectByPrimaryKey(id);
	}
	@Override
	public BBSUser getBBSUser(String name) {
		// TODO Auto-generated method stub
		return userDao.selectByName(name);
	}
	@Override
	public BBSArticle getArticleById(String id) {
		// TODO Auto-generated method stub
		return articleDao.selectById(id);
	}
	@Override
	public List<BBSArticle> getBBsArticleList() {
		// TODO Auto-generated method stub
		return articleDao.selectList();
	}
	
	@Override
	public void deleteArticle(String id) {
		// TODO Auto-generated method stub
		articleDao.deleteByPrimaryKey(id);
	}
	@Override
	public void addArticle(BBSArticle article) {
		// TODO Auto-generated method stub
		articleDao.insert(article);
	}

}
