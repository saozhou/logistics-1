package com.junqin.domain;

public class PageContent {

	private int currentPage;
	private int totalPage;
	private int nextPage;
	private int lastLongPage;
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getNextPage() {
		return nextPage;
	}
	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	public int getLastLongPage() {
		return lastLongPage;
	}
	public void setLastLongPage(int lastLongPage) {
		this.lastLongPage = lastLongPage;
	}
	
	
 
}
