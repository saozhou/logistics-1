package com.junqin.dao;

import java.util.List;

import com.junqin.domain.Lmessage;

public interface LmessageMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Lmessage record);

    int insertSelective(Lmessage record);

    Lmessage selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Lmessage record);

    int updateByPrimaryKey(Lmessage record);

	List<Lmessage> selectUnread();

	List<Lmessage> selectSloved();
}